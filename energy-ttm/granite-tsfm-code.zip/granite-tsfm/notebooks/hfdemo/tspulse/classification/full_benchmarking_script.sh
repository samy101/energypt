python full_benchmarking_script.py --datasets ArticularyWordRecognition \
                                                AtrialFibrillation \
                                                BasicMotions \
                                                CharacterTrajectories \
                                                Cricket \
                                                DuckDuckGeese \
                                                Epilepsy \
                                                ERing \
                                                EthanolConcentration \
                                                FaceDetection \
                                                FingerMovements \
                                                HandMovementDirection \
                                                Handwriting \
                                                Heartbeat \
                                                InsectWingbeat \
                                                JapaneseVowels \
                                                Libras \
                                                LSST \
                                                MotorImagery \
                                                NATOPS \
                                                PEMS-SF \
                                                PenDigits \
                                                PhonemeSpectra \
                                                RacketSports \
                                                SelfRegulationSCP1 \
                                                SelfRegulationSCP2 \
                                                SpokenArabicDigits \
                                                StandWalkJump \
                                                UWaveGestureLibrary 


