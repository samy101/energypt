# Copyright contributors to the TSFM project
#
"""Holds constant values used across modules."""

# What will appear in our paths for fast API version
API_VERSION = "v1"
